package com.onetap.uploader

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OneTapApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OneTapApp() {
    val navy = Color(0xFF101827)
    val blue = Color(0xFF315FEA)
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var title by remember { mutableStateOf("") }
    var caption by remember { mutableStateOf("") }
    var youtube by remember { mutableStateOf(true) }
    var instagram by remember { mutableStateOf(true) }
    var facebook by remember { mutableStateOf(true) }
    var notice by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri -> videoUri = uri }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("OneTap Uploader", fontWeight = FontWeight.Bold)
                        Text("Your social publishing studio", fontSize = 12.sp, color = Color.Gray)
                    }
                },
                actions = { IconButton(onClick = { notice = "Settings will be added in the next development stage." }) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings")
                } }
            )
        },
        snackbarHost = { SnackbarHost(hostState = remember { SnackbarHostState() }) }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().background(Color(0xFFF5F7FB))
                .padding(padding).verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = navy),
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Default.Movie, null, tint = Color.White, modifier = Modifier.size(42.dp))
                    Text("Upload your video", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text(
                        videoUri?.lastPathSegment ?: "Choose a video from your gallery",
                        color = Color(0xFFCBD5E1),
                        fontSize = 12.sp
                    )
                    Button(
                        onClick = { picker.launch("video/*") },
                        colors = ButtonDefaults.buttonColors(containerColor = blue)
                    ) { Text(if (videoUri == null) "Select video" else "Change video") }
                }
            }

            Text("Choose platforms", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            PlatformToggle("YouTube", "Upload as a video / Short", youtube, { youtube = it })
            PlatformToggle("Instagram", "Professional account required", instagram, { instagram = it })
            PlatformToggle("Facebook", "Page / Reels publishing access", facebook, { facebook = it })

            Text("Video details", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = title, onValueChange = { title = it },
                modifier = Modifier.fillMaxWidth(), label = { Text("Video title") },
                singleLine = true
            )
            OutlinedTextField(
                value = caption, onValueChange = { caption = it },
                modifier = Modifier.fillMaxWidth(), label = { Text("Caption / description / hashtags") },
                minLines = 4
            )
            Button(
                onClick = {
                    notice = when {
                        videoUri == null -> "Please select a video first."
                        !(youtube || instagram || facebook) -> "Select at least one platform."
                        title.isBlank() -> "Please enter a video title."
                        else -> "UI prototype ready. Connect OAuth and platform API credentials before publishing."
                    }
                },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                colors = ButtonDefaults.buttonColors(containerColor = blue),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.CloudUpload, null)
                Spacer(Modifier.width(8.dp))
                Text("PUBLISH TO SELECTED PLATFORMS", fontWeight = FontWeight.Bold)
            }
            Text(
                "Prototype only: no social accounts are connected and this button does not publish yet.",
                color = Color.Gray, fontSize = 11.sp
            )
            notice?.let {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE8EEFF))) {
                    Text(it, modifier = Modifier.padding(14.dp), color = navy)
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
fun PlatformToggle(name: String, detail: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(name, fontWeight = FontWeight.SemiBold)
                Text(detail, color = Color.Gray, fontSize = 11.sp)
            }
            Checkbox(checked = checked, onCheckedChange = onChecked)
        }
    }
}
